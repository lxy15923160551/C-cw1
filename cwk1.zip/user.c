#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "book_management(2).h"

int store_users(FILE *file, UserArray *puserarray)
{
    if (!file) //wrong file
    {
        printf("Error!\n");
        exit(-1);
    }
    fwrite(&(puserarray->length), sizeof(unsigned int), 1, file);
    User *pu = puserarray->array;
    while (pu != NULL) //no users
    {
        fwrite(pu->username, 100 * sizeof(char), 1, file); //store information
        fwrite(pu->password, 100 * sizeof(char), 1, file);
        fwrite(&(pu->length), sizeof(unsigned int), 1, file);
        fwrite(&(pu->bookid1), sizeof(unsigned int), 1, file);
        fwrite(&(pu->bookid2), sizeof(unsigned int), 1, file);
        fwrite(&(pu->bookid3), sizeof(unsigned int), 1, file);
        pu = pu->next;
    }
    return 0;
}

int load_users(FILE *file, UserArray *puserarray)
{
    if (!file) //wrong file
    {
        printf("The wrong databases.\n");
        exit(-1);
    }
    fread(&(puserarray->length), sizeof(unsigned int), 1, file);
    puserarray->array = NULL;
    User *pu = puserarray->array;
    pu = (User *)malloc(sizeof(User));           //give memory
    for (int i = 0; i < puserarray->length; i++) //read users until there is no book
    {
        pu->next = (User *)malloc(sizeof(User)); //give memory
        pu->username = (char *)malloc(100 * sizeof(char));
        pu->password = (char *)malloc(100 * sizeof(char));
        memset(pu->username, 0, sizeof(char) * 100);
        memset(pu->password, 0, sizeof(char) * 100);

        fread(pu->username, 100 * sizeof(char), 1, file); //read information
        fread(pu->password, 100 * sizeof(char), 1, file);
        fread(&(pu->length), sizeof(unsigned int), 1, file);
        fread(&(pu->bookid1), sizeof(unsigned int), 1, file);
        fread(&(pu->bookid2), sizeof(unsigned int), 1, file);
        fread(&(pu->bookid3), sizeof(unsigned int), 1, file);
        pu = pu->next;
    }

    return 0;
}

int add_users(User *puser, UserArray *puserarray)
{
    User *pu;
    pu = puserarray->array;
    if (puserarray->length == 0) //if this user is the first one
    {
        puserarray->array = puser;
        puserarray->length++;
        return 0;
    }
    while (pu->next != NULL) //find the last user
    {
        pu = pu->next;
    }
    pu->next = puser;
    puserarray->length++;
    return 0;
}

int borrow_book(Book *pbook, User *puser, BookArray *pborrowbook)
{
    Book *pb;
    pb = pborrowbook->array;
    if (pbook->id == puser->bookid1 || pbook->id == puser->bookid2 || pbook->id == puser->bookid3)
    {
        printf("Sorry, you already have a copy of this book on loan.\n");
        return 1;
    }
    if (puser->length == 0) //user hasn't borrowed any books
    {
        pbook->copies--;
        puser->bookid1 = pbook->id;
        puser->length++;
        pbook->state = 1;

        pborrowbook->length++;
        pborrowbook->array = pbook;
        pb = pborrowbook->array;
        pb->nextfind = NULL;
        return 0;
    }
    if (puser->length == 1) //user has borrowed one book
    {
        pbook->copies--;
        puser->bookid2 = pbook->id;
        puser->length++;
        pbook->state = 1;

        pborrowbook->length++;
        pborrowbook->array->nextfind = pbook;
        pb->nextfind = pborrowbook->array;
        pb->nextfind->nextfind = NULL;
        return 0;
    }
    if (puser->length == 2) //user has borrowed two books
    {
        pbook->copies--;
        puser->bookid3 = pbook->id;
        puser->length++;
        pbook->state = 1;

        pborrowbook->length++;
        pborrowbook->array->nextfind->nextfind = pbook;
        pb->nextfind->nextfind = pborrowbook->array;
        pb->nextfind->nextfind = NULL;
        return 0;
    }
}

int return_book(Book *pbook, User *puser, BookArray *pborrowbook)
{
    if (pbook->id == puser->bookid3) //user has borrowed three books
    {
        pbook->copies++;
        puser->bookid3 = 0;
        puser->length--;
        pbook->state = 0;

        pborrowbook->length--;
        pborrowbook->array->nextfind->nextfind = NULL;
        return 0;
    }
    if (pbook->id == puser->bookid2) //user has borrowed two books
    {
        pbook->copies++;
        puser->bookid2 = 0;
        puser->length--;
        pbook->state = 0;

        pborrowbook->array->nextfind = NULL;
        pborrowbook->length--;
        return 0;
    }
    if (pbook->id == puser->bookid1) //user has borrowed one book
    {
        pbook->copies++;
        puser->bookid1 = 0;
        puser->length--;
        pbook->state = 0;

        pborrowbook->array = NULL;
        pborrowbook->length--;
        return 0;
    }
}
