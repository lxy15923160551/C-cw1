#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "book_management(2).h"

int store_books(FILE *file, BookArray *pbookarray)
{
    if (!file) //wrong file
    {
        printf("Error!\n");
        exit(-1);
    }
    fwrite(&(pbookarray->length), sizeof(unsigned int), 1, file);
    Book *pb = pbookarray->array;
    while (pb != NULL) //if there are no books
    {
        fwrite(pb->authors, 100 * sizeof(char), 1, file);
        fwrite(&(pb->copies), sizeof(unsigned int), 1, file);
        fwrite(&(pb->id), sizeof(unsigned int), 1, file);
        fwrite(pb->title, 100 * sizeof(char), 1, file);
        fwrite(&(pb->year), sizeof(unsigned int), 1, file);
        fwrite(&(pb->state), sizeof(unsigned int), 1, file);
        pb = pb->next;
    }
    return 0;
}

int load_books(FILE *file, BookArray *pbookarray)
{
    if (!file) //wrong file
    {
        printf("The wrong databases.\n");
        exit(-1);
    }
    fread(&(pbookarray->length), sizeof(unsigned int), 1, file);
    pbookarray->array = NULL;
    Book *pb = pbookarray->array;
    pb = (Book *)malloc(sizeof(Book));           //give memory
    for (int i = 0; i < pbookarray->length; i++) //read books until there is no book
    {
        pb->next = (Book *)malloc(sizeof(Book)); //give memory
        pb->title = (char *)malloc(100 * sizeof(char));
        pb->authors = (char *)malloc(100 * sizeof(char));
        memset(pb->title, 0, sizeof(char) * 100); //delete
        memset(pb->authors, 0, sizeof(char) * 100);

        fread(pb->authors, 100 * sizeof(char), 1, file); //read the information from txt
        fread(&(pb->copies), sizeof(unsigned int), 1, file);
        fread(&(pb->id), sizeof(unsigned int), 1, file);
        fread(pb->title, 100 * sizeof(char), 1, file);
        fread(&(pb->year), sizeof(unsigned int), 1, file);
        fread(&(pb->state), sizeof(unsigned int), 1, file);
        pb = pb->next;
    }
    return 0;
}

int add_book(Book *pbook, BookArray *pbookarray)
{
    Book *pb;
    pb = pbookarray->array;
    if (pbookarray->length == 0) //if there are no books in bookarray
    {
        pbook->id = 1;
        pbookarray->array = pbook;
        pbookarray->length++;
        return 0;
    }

    Book *bp;
    bp = pbookarray->array;
    for (int i = 0; i < pbookarray->length; i++) //check if the book existed or not
    {
        if (strcmp(pbook->title, pbookarray->array->title) == 0) //exist the same book
        {
            return 1;
        }
        bp = bp->next;
    }

    while (pb->next != NULL) //find the last book
    {
        pb = pb->next;
    }
    pbook->id = pb->id + 1;
    pb->next = pbook;
    pbookarray->length++;
    return 0;
}

int remove_book(unsigned int id, BookArray *pbookarray)
{
    Book *pb;
    pb = pbookarray->array;
    for (int i = 0; i < pbookarray->length; i++)
    {
        if (id == pb->id && pb->next == 0) //check if there is the same book
        {
            memset(pbookarray->array, 0, sizeof(Book));
            pbookarray->length--;
            return 0; //returns 0 successfully delete
        }
        pb = pb->next;
    }
    return 1; // if there is no this book
}

void find_book_by_title(const char *title, BookArray *pbookarray, BookArray *pfindbook)
{
    Book *pb;
    pb = pbookarray->array;
    Book *pbb = pfindbook->array;
    for (int i = 0; i < pbookarray->length; i++)
    {
        if (strcmp(pb->title, title) == 0) //if there is the same string
        {
            if (pfindbook->length == 0)
            {
                pfindbook->array = pb;
                pfindbook->length++;
                pbb = pfindbook->array;
                pbb->nextfind = NULL;
            }
            else
            {
                pbb->nextfind = pb;
                pfindbook->length++;
                pbb = pbb->nextfind;
                pbb->nextfind = NULL;
            }
        }
        pb = pb->next;
    }
    if (pfindbook->length == 0) //no relater books in the library
    {
        printf("No related books\n");
    }
    printf("ID    Title           Authors     Year  Copies\n"); //print the bookarray of found
    for (int i = 0; i < pfindbook->length; i++)
    {
        printf("%i     ", pbb->id);
        int a = strlen(pbb->title);
        printf("%s", pbb->title);
        for (int i = 0; i < 16 - a; i++)
        {
            printf(" ");
        }
        printf("%s", pbb->authors);
        int b = strlen(pbb->authors);
        for (int i = 0; i < 16 - b; i++)
        {
            printf(" ");
        }
        printf("%i  ", pbb->year);
        printf("%i", pbb->copies);
        pbb = pbb->next;
    }
}

void find_book_by_author(const char *author, BookArray *pbookarray, BookArray *pfindbook)
{
    Book *pb;
    pb = pbookarray->array;
    Book *pbb = pfindbook->array;
    for (int i = 0; i < pbookarray->length; i++)
    {
        if (strcmp(pb->authors, author) == 0) //have the same string
        {
            if (pfindbook->length == 0)
            {
                pfindbook->array = pb;
                pfindbook->length++;
                pbb = pfindbook->array;
                pbb->nextfind = NULL;
            }
            else
            {
                pbb->nextfind = pb;
                pfindbook->length++;
                pbb = pbb->nextfind;
                pbb->nextfind = NULL;
            }
        }
        pb = pb->next;
    }
    if (pfindbook->length == 0) //no relater books in the library
    {
        printf("No related books\n");
    }
    printf("ID    Title           Authors     Year  Copies\n"); //print the bookarray of found
    for (int i = 0; i < pfindbook->length; i++)
    {
        printf("%i     ", pbb->id);
        int a = strlen(pbb->title);
        printf("%s", pbb->title);
        for (int i = 0; i < 16 - a; i++)
        {
            printf(" ");
        }
        printf("%s", pbb->authors);
        int b = strlen(pbb->authors);
        for (int i = 0; i < 16 - b; i++)
        {
            printf(" ");
        }
        printf("%i  ", pbb->year);
        printf("%i", pbb->copies);
        pbb = pbb->next;
    }
}

void find_book_by_year(unsigned int year, BookArray *pbookarray, BookArray *pfindbook)
{
    Book *pb;
    pb = pbookarray->array;
    Book *pbb = pfindbook->array;
    for (int i = 0; i < pbookarray->length; i++)
    {
        if (pb->year == year) //have the same string
        {
            if (pfindbook->length == 0)
            {
                pfindbook->array = pb;
                pfindbook->length++;
                pbb = pfindbook->array;
                pbb->nextfind = NULL;
            }
            else
            {
                pbb->nextfind = pb;
                pfindbook->length++;
                pbb = pbb->nextfind;
                pbb->nextfind = NULL;
            }
        }
        pb = pb->next;
    }
    if (pfindbook->length == 0) //no relater books in the library
    {
        printf("No related books\n");
    }
    printf("ID    Title           Authors     Year  Copies\n"); //print the bookarray of found
    for (int i = 0; i < pfindbook->length; i++)
    {
        printf("%i     ", pbb->id);
        int a = strlen(pbb->title);
        printf("%s", pbb->title);
        for (int i = 0; i < 16 - a; i++)
        {
            printf(" ");
        }
        printf("%s", pbb->authors);
        int b = strlen(pbb->authors);
        for (int i = 0; i < 16 - b; i++)
        {
            printf(" ");
        }
        printf("%i  ", pbb->year);
        printf("%i", pbb->copies);
        pbb = pbb->next;
    }
}