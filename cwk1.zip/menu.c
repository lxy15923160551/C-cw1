#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "book_management(2).h"

void printmenu()
{
    printf("Please choose an option:\n");
    printf("1)Register anaccount\n");
    printf("2)Login\n");
    printf("3)Search for books\n");
    printf("4)Display all books\n");
    printf("5)Quit\n");
    printf(" Option:");
}

int checkusersame(const char *check, UserArray *puserarray)
{
    User *pu;
    pu = puserarray->array;
    if (puserarray->length == 0) //if the user is the first user
    {
        return 0;
    }
    for (int i = 0; i < puserarray->length; i++) //there is the same username
    {
        if (strcmp(check, pu->username) == 0)
        {
            return 1; //same
        }
        pu = pu->next;
    }
    return 0; //different
}

int checkpasssame(const char *check, UserArray *puserarray)
{
    User *pu;
    pu = puserarray->array;
    for (int i = 0; i < puserarray->length; i++)
    {
        if (strcmp(check, pu->password) == 0)
        {
            return 1; //sanme
        }
        pu = pu->next;
    }
    return 0; //different
}

void limenu()
{
    printf("\n");
    printf("(logged in as: librarian)\n");
    printf("Please choose an option:\n");
    printf("1)Add a book\n");
    printf("2)Remove a book\n");
    printf("3)search for books\n");
    printf("4)Display all books\n");
    printf("5)log out\n");
    printf(" Option:");
}

void semenu()
{
    printf("\n");
    printf("Please choose an option:\n");
    printf("1)Find books by title\n");
    printf("2)Find books by author\n");
    printf("3)Find books by year\n");
    printf("4)Return to previous menu\n");
    printf(" Option:");
}

void usmenu(const char *username)
{
    printf("(Logged in as: %s)\n", username);
    printf("1)Borrow a book\n");
    printf("2)Return a book\n");
    printf("3)Search for books\n");
    printf("4)Display all books\n");
    printf("5)Log out\n");
    printf(" Option:");
}

void display_all_books(BookArray *pbookarray)
{
    Book *pb;
    pb = pbookarray->array;
    printf("ID    Title           Authors         Year  Copies\n");
    for (int i = 0; i < pbookarray->length; i++)
    {
        printf("%i     ", pb->id);
        int a = strlen(pb->title);
        printf("%s", pb->title);
        for (int i = 0; i < 16 - a; i++)
        {
            printf(" ");
        }
        printf("%s", pb->authors);
        int b = strlen(pb->authors);
        for (int i = 0; i < 16 - b; i++)
        {
            printf(" ");
        }
        printf("%i  ", pb->year);
        printf("%i", pb->copies);
        pb = pb->next;
    }
}

void print_borrow_book(BookArray *pborrowbook)
{
    Book *pb;
    pb = pborrowbook->array;
    printf("ID    Title           Authors         Year  Copies\n");
    for (int i = 0; i < pborrowbook->length; i++)
    {
        printf("%i     ", pb->id);
        int a = strlen(pb->title);
        printf("%s", pb->title);
        for (int i = 0; i < 16 - a; i++)
        {
            printf(" ");
        }
        printf("%s", pb->authors);
        int b = strlen(pb->authors);
        for (int i = 0; i < 16 - b; i++)
        {
            printf(" ");
        }
        printf("%i  ", pb->year);
        printf("%i", pb->copies);
        pb = pb->next;
    }
}