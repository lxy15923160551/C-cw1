#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "book_management(2).h"

int main()
{
    int option, year1, copies1, id;
    char *username, *password, *title, *author, *year, *copies;
    BookArray *pbookarray;
    UserArray *puserarray;
    UserArray head;
    username = (char *)malloc(100 * sizeof(char));
    password = (char *)malloc(100 * sizeof(char));
    title = (char *)malloc(100 * sizeof(char));
    author = (char *)malloc(100 * sizeof(char));
    year = (char *)malloc(100 * sizeof(char));
    copies = (char *)malloc(100 * sizeof(char));
    //
    load_books("book.txt", pbookarray);
    load_users("user.txt", puserarray);
mainmenu:
    printmenu();
    scanf("%i", &option);
    while (option != 1 && option != 2 && option != 3 && option != 4 && option != 5)
    {
        printf("Sorry, the option you entered was invalid, please try again.\n");
        printmenu();
        scanf("%i", &option);
    }
    if (option == 1) //主菜单 注册账户
    {
        printf("Please enter a username:");
        scanf("%s", username);
        printf("Please enter a password:");
        scanf("%s", password);
        while (checkusersame(username, puserarray) == 1 || strcmp(username, "librarian") == 0)
        {
            printf("Sorry, registration unsuccessful, the username you entered already exists.\n");
            printf("Please enter a username:");
            scanf("%s", username);
            printf("Please enter a password:");
            scanf("%s", password);
        }
        User *a;
        a->id = 1;
        a->username = username;
        a->password = password;
        add_users(a, puserarray);
        printf("Registered library account successfully!\n");
        goto mainmenu;
    }

    else if (option == 2) // 主菜单 登录账户
    {
        printf("Please enter your username:");
        scanf("%s", username);
        printf("Please enter your password:");
        scanf("%s", password);
        if (strcmp(username, "librarian") == 0 && strcmp(password, "librarian") == 0) //登入图书管理员
        {
        ba:
            limenu();
            scanf("%i", &option);
            while (option != 1 && option != 2 && option != 3 && option != 4 && option != 5) //判斷是否有效
            {
                printf("Sorry, the option you entered was invalid, please try again.\n");
                printmenu();
                scanf("%i", &option);
            }
            printf("\n");
            if (option == 1) //图书管理员增加书籍
            {
            baa:
                printf("Enter the title of the book you wish to add:");
                fflush(stdin);
                gets(title);
                printf("Enter the author of the book you wish to add:");
                fflush(stdin);
                gets(author);
                printf("Enter the year that the book you wish to add was released:");
                fflush(stdin);
                gets(year);
                printf("Enter the number of copies of the book that you wish to add:");
                gets(copies);
                if (strspn(year, "0123456789") != strlen(year) || strspn(copies, "0123456789") != strlen(copies))
                {
                    printf("Sorry, you attempted to add an invalid book, please try again.\n");
                    goto baa;
                }
                year1 = atoi(year);
                copies1 = atoi(copies);
                Book *a;
                a->title = title;
                a->authors = author;
                a->year = year1;
                a->copies = copies1;
                if (add_book(a, pbookarray) == 1)
                {
                    printf("This book has existed, please try again.");
                }
                printf("Book was successfully added!");
                goto ba;
            }
            if (option == 2) //图书管理员删除图书
            {
                printf("Please enter the id of the book you wish to remove:");
                scanf("%i", id);
                if (remove_book(id, pbookarray) == 0)
                {
                    printf("This book was successfully removed.\n");
                    goto ba;
                }
                else
                {
                    printf("This book doesn't exist here.\n");
                    goto ba;
                }
            }
            if (option == 3) //搜索图书
            {
                printf("Loading search menu...\n");
            bac:
                semenu();
                scanf("%i", &option);
                while (option != 1 && option != 2 && option != 3 && option != 4)
                {
                    printf("Sorry, the option you entered was invalid, please try again.\n");
                    semenu;
                    scanf("%i", &option);
                }
                if (option == 1)
                {
                    printf("Please enter title:");
                    gets(title);
                    BookArray findbook = find_book_by_title(title, pbookarray);
                    printf("ID    Title           Authors     Year  Copies\n");
                    for (int i = 0; i < findbook.length; i++)
                    {
                        printf("%i%s%s%i%i", findbook.array->id, findbook.array->title, findbook.array->authors, findbook.array->year, findbook.array->copies);
                        findbook.array = findbook.array->next;
                    }
                    goto bac;
                }
                if (option == 2)
                {
                    printf("Please enter author:");
                    gets(author);
                    BookArray findbook = find_book_by_author(author, pbookarray);
                    printf("ID    Title           Authors     Year  Copies\n");
                    for (int i = 0; i < findbook.length; i++)
                    {
                        printf("%i%s%s%i%i", findbook.array->id, findbook.array->title, findbook.array->authors, findbook.array->year, findbook.array->copies);
                        findbook.array = findbook.array->next;
                    }
                    goto bac;
                }
                if (option == 3)
                {
                    printf("Please enter year:");
                    gets(year);
                    year1 = year;
                    BookArray findbook = find_book_by_year(year1, pbookarray);
                    printf("ID    Title           Authors     Year  Copies\n");
                    for (int i = 0; i < findbook.length; i++)
                    {
                        printf("%i%s%s%i%i", findbook.array->id, findbook.array->title, findbook.array->authors, findbook.array->year, findbook.array->copies);
                        findbook.array = findbook.array->next;
                    }
                    goto bac;
                }
                if (option == 4)
                {
                    printf("Returning to previous menu...\n");
                    goto ba;
                }
            }
            if (option == 4) //展示图书
            {
                display_all_books(pbookarray);
                goto ba;
            }
            if (option == 5) //退回主界面
            {
                printf("Logging out...\n");
                goto mainmenu;
            }
        }
        if (checkusersame(username, puserarray) == 1 && checkpasssame(password, puserarray) == 1) //登入用户
        {
        bb:
            usmenu(username);
            scanf("%i", &option);
            while (option != 1 && option != 2 && option != 3 && option != 4 && option != 5) //判斷是否有效
            {
                printf("Sorry, the option you entered was invalid, please try again.\n");
                printmenu();
                scanf("%i", &option);
            }
            if (option == 1) //用户借书
            {
                printf("Enter the ID number of the book you wish to borrow:");
                scanf("%i", id);
                while (pbookarray->array != NULL)
                {
                    if (pbookarray->array->id == id)
                    {
                        break;
                    }
                    pbookarray->array = pbookarray->array->next;
                }
                while (puserarray->array != NULL)
                {
                    if (puserarray->array->username == username)
                    {
                        break;
                    }
                    puserarray->array = puserarray->array->next;
                }
                if (pbookarray->array->id == id)
                {
                    if (borrow_book(pbookarray->array, puserarray->array) == 0)
                    {
                        printf("You have successfully borrowed the book!\n");
                        goto bb;
                    }
                }
                else
                {
                    printf("This book is not available here.\n");
                    goto bb;
                }
            }
            if (option == 2) //用户还书
            {
                printf("Please enter the id of the book you wish to return.");
                scanf("%i", id);
                while (pbookarray->array != NULL)
                {
                    if (pbookarray->array->id == id)
                    {
                        break;
                    }
                    pbookarray->array = pbookarray->array->next;
                }
                while (puserarray->array != NULL)
                {
                    if (puserarray->array->username == username)
                    {
                        break;
                    }
                    puserarray->array = puserarray->array->next;
                }
                if (pbookarray->array->id == id)
                {
                    return_book(pbookarray->array, puserarray->array);
                    printf("You have successfully returned the book!\n");
                    goto bb;
                }
                else
                {
                    printf("This book doesn't exist here.\n");
                    goto bb;
                }
            }
            if (option == 3) //用户查书
            {
                printf("Loading search menu...\n");
            bbc:
                semenu();
                scanf("%i", &option);
                while (option != 1 && option != 2 && option != 3 && option != 4)
                {
                    printf("Sorry, the option you entered was invalid, please try again.\n");
                    semenu;
                    scanf("%i", &option);
                }
                if (option == 1)
                {
                    printf("Please enter title:");
                    gets(title);
                    BookArray findbook = find_book_by_title(title, pbookarray);
                    printf("ID    Title           Authors     Year  Copies\n");
                    for (int i = 0; i < findbook.length; i++)
                    {
                        printf("%i%s%s%i%i", findbook.array->id, findbook.array->title, findbook.array->authors, findbook.array->year, findbook.array->copies);
                        findbook.array = findbook.array->next;
                    }
                    goto bbc;
                }
                if (option == 2)
                {
                    printf("Please enter author:");
                    gets(author);
                    BookArray findbook = find_book_by_author(author, pbookarray);
                    printf("ID    Title           Authors     Year  Copies\n");
                    for (int i = 0; i < findbook.length; i++)
                    {
                        printf("%i%s%s%i%i", findbook.array->id, findbook.array->title, findbook.array->authors, findbook.array->year, findbook.array->copies);
                        findbook.array = findbook.array->next;
                    }
                    goto bbc;
                }
                if (option == 3)
                {
                    printf("Please enter year:");
                    gets(year);
                    year1 = year;
                    BookArray findbook = find_book_by_year(year1, pbookarray);
                    printf("ID    Title           Authors     Year  Copies\n");
                    for (int i = 0; i < findbook.length; i++)
                    {
                        printf("%i%s%s%i%i", findbook.array->id, findbook.array->title, findbook.array->authors, findbook.array->year, findbook.array->copies);
                        findbook.array = findbook.array->next;
                    }
                    goto bbc;
                }
                if (option == 4)
                {
                    printf("Returning to previous menu...\n");
                    goto bb;
                }
            }
            if (option == 4) //展示书籍
            {
                display_all_books(pbookarray);
                goto bb;
            }
            if (option == 5) //用户返回上一页
            {
                printf("Logging out...\n");
                goto mainmenu;
            }
        }
    }

    else if (option == 3) //主菜单 查询书籍
    {
        printf("Loading search menu...\n");
    c:
        semenu();
        scanf("%i", &option);
        while (option != 1 && option != 2 && option != 3 && option != 4)
        {
            printf("Sorry, the option you entered was invalid, please try again.\n");
            semenu;
            scanf("%i", &option);
        }
        if (option == 1)
        {
            printf("Please enter title:");
            gets(title);
            BookArray findbook = find_book_by_title(title, pbookarray);
            printf("ID    Title           Authors     Year  Copies\n");
            for (int i = 0; i < findbook.length; i++)
            {
                printf("%i%s%s%i%i", findbook.array->id, findbook.array->title, findbook.array->authors, findbook.array->year, findbook.array->copies);
                findbook.array = findbook.array->next;
            }
            goto c;
        }
        if (option == 2)
        {
            printf("Please enter author:");
            gets(author);
            BookArray findbook = find_book_by_author(author, pbookarray);
            printf("ID    Title           Authors     Year  Copies\n");
            for (int i = 0; i < findbook.length; i++)
            {
                printf("%i%s%s%i%i", findbook.array->id, findbook.array->title, findbook.array->authors, findbook.array->year, findbook.array->copies);
                findbook.array = findbook.array->next;
            }
            goto c;
        }
        if (option == 3)
        {
            printf("Please enter year:");
            gets(year);
            year1 = year;
            BookArray findbook = find_book_by_year(year1, pbookarray);
            printf("ID    Title           Authors     Year  Copies\n");
            for (int i = 0; i < findbook.length; i++)
            {
                printf("%i%s%s%i%i", findbook.array->id, findbook.array->title, findbook.array->authors, findbook.array->year, findbook.array->copies);
                findbook.array = findbook.array->next;
            }
            goto c;
        }
        if (option == 4)
        {
            printf("Loading main menu...\n");
            goto mainmenu;
        }
    }

    else if (option == 4) //主菜单 展示书籍
    {
        display_all_books(pbookarray);
        goto mainmenu;
    }

    else // 主菜单 退出程序
    {
        printf("Thank you for using the library!\n");
        printf("Goodbye!");
        store_books("book.txt", pbookarray);
        store_users("user.txt", puserarray);
        return 0;
    }
}